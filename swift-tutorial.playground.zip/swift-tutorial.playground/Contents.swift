import UIKit

var greeting:String = "Hello, playground" //ur choice to decide what type of data u want for it
var playerScore = 0
var cpuScore:Int = 0
let constant = 100 //let doesnt let you change the assigned data

/*
 basicdata types:
 1. string: text data like "hi"
 2. int: a whole number in postive or negative range like -1 or 200. no decimals
 3. double: decimal numbers
 4. bool: a value that can either be true or false
 */

//swift variables
playerScore += 1

print(playerScore)
print(constant)

/* swift Functions */

func myFunction(){
    print("hello")
}

myFunction()
